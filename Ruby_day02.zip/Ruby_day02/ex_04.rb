res = true

for arg in ARGV
    if res == true
        res = arg.to_i
    elsif res%2 == 1
        res += arg.to_i
    elsif res%2 == 0
        res -= arg.to_i
    end
end

res = 0 if res ==  true
p res