def count_words(array)
    array = array.tally
    res =array.sort_by {|_key, value| value}.to_h
    return res
end

p count_words(['BMW', 'Mercedes', 'Volvo', 'Tesla', 'BMW', 'Volvo'])
