def validMail(email)
    res = false
  
  if email.match(/\A[\w+\-.]+@[a-z\d\-]+(\.[a-z]+){,3}\z/i)
        res = true
      end
    return res
  end

p validMail("Moreau.solo11@gmail.com")
p validMail("Moreau.solo11@gmail.c.c")
p validMail("Moreau.solo11@gmail.c.c.c")
p validMail("Moreau.solo11@gmail.c.c.c.c")


# /\A[\w+\-.]+@[a-z\d\-]+(\.[a-z\d\-]+)*\.[a-z]+\z/i