def  display_time(time)
    p "#{time.strftime("%H:%M:%S")},#{time.strftime("%A")}, #{time.strftime("%w").to_i + 1} day of the #{time.strftime("%U")} week of #{time.strftime("%Y")}, #{time.strftime("%B")}"
end

display_time(Time.new)
p Time.now