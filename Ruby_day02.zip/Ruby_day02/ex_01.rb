def increment(array)
    res=[]
    array.each do |value|
        type = value.class
        res << value+=1 if value.is_a? Integer
        res << value+="++" if value.is_a? String
        res << value unless value.is_a? Integer or value.is_a? String
    end
    return res
end

p increment([{}, [1, 2, 3], 4, 'salut', 'toa'])
