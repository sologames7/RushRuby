class Sendable
    attr_accessor :body, :subject, :to
    attr_reader :from, :created_at, :updated_at, :sent_at
    def initialize(*args)
        p "DNA has been took"
        @initialized = true
        
        @created_at = Time.now
        @updated_at = Time.now
        @sent_at = nil
        
        if args != []
            @subject = args[0][:subject] unless args[0].dig(:subject).nil?
            @body = args[0][:body] unless args[0].dig(:body).nil?
            @from = args[0][:from] unless args[0].dig(:from).nil?
            @to = args[0][:to] unless args[0].dig(:to).nil?
        end
    end

    def sent!
        raise "DataAlreadySent" unless @sent_at.nil?

        @sent_at = Time.now
    end
end


# t = Sendable.new({subject: "Anniversaire"})
# t.sent