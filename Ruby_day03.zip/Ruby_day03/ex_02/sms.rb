require './sendable.rb'

class Sms < Sendable
    def initialize(*args)
        super
        puts "Yes father"
    end
end

t = Sms.new
t.sent
p t.sent_at