require './sendable.rb'

class Email < Sendable
    def initialize(*args)
        super
        puts "Yes father"
    end

end

t = Email.new
t.sent!
p t.sent_at