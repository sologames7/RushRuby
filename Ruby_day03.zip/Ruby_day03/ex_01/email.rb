class Email
    attr_accessor :body, :subject, :to
    attr_reader :from, :created_at, :updated_at, :sent_at
    def initialize(*args)
        @initialized = true
        
        @created_at = Time.now
        @updated_at = Time.now
        @sent_at = nil
        
        if args != []
            @subject = args[0][:subject]
            @body = args[0][:body]
            @from = args[0][:from]
            @to = args[0][:to]
        end
    end

    
end

s = Email.new()
t = Email.new({subject: "Anniversaire"})

p t.subject
p t.body
