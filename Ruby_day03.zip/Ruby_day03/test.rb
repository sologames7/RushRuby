class Person
    attr_accessor :name
end
  
person = Person.new
  
person.name = "Educative" # you can both modify ...
puts person.name          # ... and read variable