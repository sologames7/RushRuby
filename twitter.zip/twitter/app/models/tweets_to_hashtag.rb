class TweetsToHashtag < ApplicationRecord
    belongs_to :tweet
    belongs_to :hashtag
    validates :tweet, presence: true
    validates :hashtag, presence: true
end