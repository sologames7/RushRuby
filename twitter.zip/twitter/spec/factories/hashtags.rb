FactoryBot.define do
    factory :hashtag do
      hashtag { Faker::Superhero.power }
    end
end