require 'rails_helper'

RSpec.describe Hashtag, type: :model do
  describe 'when hashtag body is less than 1 character' do
    it 'does not accept contentless hashtags' do
      expect { FactoryBot.create!(:hashtag, hashtag: '') }.to raise_exception
    end
  end
end

describe 'when hashtags is more than 30 characters' do
  it 'does not accept too long hashtags' do
    expect { FactoryBot.create(:hashtag, hashtag: Faker::Hipster.paragraph_by_chars(characters: 31, supplemental: false)) }.to raise_exception
  end
end