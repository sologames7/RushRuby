def validate str
    chars = ('a'..'z').to_a + ('A'..'Z').to_a + ('0'..'9').to_a
    str.chars.detect {|ch| !chars.include?(ch)}.nil?
   end

list =""
for arg in ARGV
    len = arg.size - 1
    for c in (0..len) do
        list += arg[c] if validate arg[c]
    end
end

p list.size

