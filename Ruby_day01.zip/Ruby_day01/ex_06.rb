def puts_args_in_array(*others)
    res = []
    others.each{|e| res << e}
    return res
end

p puts_args_in_array("coucou","test1","test2")
