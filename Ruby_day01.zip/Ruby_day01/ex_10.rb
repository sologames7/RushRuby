def display_all(hash)
    par = hash.keys
    h = hash[par[0]]
    p h
    res=[]
    h[0].each do |key, value|
        type = value.class
        res << { key => { type => value } }
    end
    return res
end


item = {"items" => ["Car1" => 'BMW',"Car2" => 'Mercedes',"Student1" => 'Patrick',"Student2" => 'Baudouin']}

# p item.keys
# p item["items"]

p display_all({"items" => ["Car1" => 'BMW',"Car2" => 'Mercedes',"Student1" => 'Patrick',"Student2" => 'Baudouin']})