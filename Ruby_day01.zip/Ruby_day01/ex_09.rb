for c in (1..100) do
    a = c%3 == 0 && c%5 == 0 ? "FizzBuzz" : (c%3 == 0 ? "Fizz" : (c%5 == 0 ? "Buzz" : c))
    p a
end

