def my_show_platipus(n)
    err ="parameter must be positive"
    res = err if n<0
    res = ("platipus \n")*n unless n<0
    return res

end

# puts my_show_platipus(4)
# puts my_show_platipus(7)
# puts my_show_platipus(0)
puts my_show_platipus(4)
puts my_show_platipus(-1)
