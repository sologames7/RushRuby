def my_args_handler(*others)
    p others.join(',')
end

my_args_handler("coucou","test1","test2")
