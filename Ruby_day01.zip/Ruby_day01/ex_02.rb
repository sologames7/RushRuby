list =""
for arg in ARGV
    list+=arg
 end
p list