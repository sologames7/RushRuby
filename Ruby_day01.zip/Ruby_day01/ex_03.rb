list =""
temp =[]

for arg in ARGV
    charL = arg.split('')
    charL.each do |c|
        if ('0'..'9').include? c
            list +=c
        end
    end
end

p list
